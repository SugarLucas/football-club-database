﻿# project_b4h1q_v5a3b_y1g7t


There are five components to this project: the cover page, head page, player page, team page, and staff page. There are many functionalities our database can do including inserting, deleting, and updating players. Also, count how many players and show all the player's details. In addition, it also shows the teams which have players from two countries the users inputted(division). 
In the teams page, you can view all or some selected columns of all teams in the database. I can also filter teams based on standings, age, and points. Another function is to calculate the total salary of each team(which implemented nested aggregation). 
On the staff page, you can show the number of staffs grouped by countries, show the names of all staff and also join the staff and team table to show it as one table.


<img width="1441" alt="Screenshot 2023-04-05 at 3 36 11 PM" src="https://media.github.students.cs.ubc.ca/user/16904/files/ea849352-e456-49a9-aa75-2b505702701b">
